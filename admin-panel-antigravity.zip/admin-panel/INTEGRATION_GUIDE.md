# Admin Panel Integration Guide for Maison d'Orient

## Overview

This admin panel is designed as a comprehensive management system for your real estate website. It provides features for managing properties, neighborhoods, blog posts, leads, users, SEO settings, and media files.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Installation Steps](#installation-steps)
3. [File Structure](#file-structure)
4. [Database Setup](#database-setup)
5. [Environment Configuration](#environment-configuration)
6. [Authentication Setup](#authentication-setup)
7. [Component Integration](#component-integration)
8. [API Routes Setup](#api-routes-setup)
9. [SEO Configuration](#seo-configuration)
10. [Cloudinary Integration](#cloudinary-integration)
11. [Customization Guide](#customization-guide)
12. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before integrating the admin panel, ensure you have:

- Node.js 18+ installed
- PostgreSQL or MySQL database
- Cloudinary account (for media uploads)
- The existing Maison d'Orient Next.js project

### Required Dependencies

Add these dependencies to your `package.json`:

```bash
npm install @prisma/client next-auth @auth/prisma-adapter bcryptjs react-dropzone
npm install -D prisma @types/bcryptjs
```

---

## Installation Steps

### Step 1: Copy Admin Panel Files

Extract the admin panel zip file and copy the contents to your project:

```bash
# Copy components
cp -r admin-panel/src/components/admin/* src/components/admin/

# Copy app routes
cp -r admin-panel/src/app/[locale]/admin/* src/app/[locale]/admin/

# Copy API routes
cp -r admin-panel/src/app/api/admin/* src/app/api/admin/

# Copy lib files
cp -r admin-panel/src/lib/admin/* src/lib/admin/

# Copy types
cp admin-panel/src/types/admin.ts src/types/

# Copy Prisma schema
cp admin-panel/prisma/schema.prisma prisma/
```

### Step 2: Merge Prisma Schema

If you have an existing Prisma schema, merge the models from `admin-panel/prisma/schema.prisma` into your existing schema.

### Step 3: Update Next.js Configuration

Add these configurations to your `next.config.ts`:

```typescript
const nextConfig = {
  // ... existing config
  images: {
    remotePatterns: [
      // ... existing patterns
      {
        protocol: 'https',
        hostname: 'res.cloudinary.com',
      },
    ],
  },
  // Protect admin routes
  async redirects() {
    return [
      {
        source: '/:locale/admin',
        destination: '/:locale/admin/dashboard',
        permanent: true,
      },
    ];
  },
};
```

---

## File Structure

```
src/
├── app/
│   ├── [locale]/
│   │   └── admin/
│   │       ├── dashboard/
│   │       │   └── page.tsx          # Dashboard overview
│   │       ├── properties/
│   │       │   ├── page.tsx          # Property list
│   │       │   └── [id]/
│   │       │       └── page.tsx      # Property edit/create
│   │       ├── neighborhoods/
│   │       │   ├── page.tsx
│   │       │   └── [id]/page.tsx
│   │       ├── blog/
│   │       │   ├── page.tsx
│   │       │   └── [id]/page.tsx
│   │       ├── leads/
│   │       │   └── page.tsx
│   │       ├── users/
│   │       │   └── page.tsx
│   │       ├── seo/
│   │       │   └── page.tsx          # SEO management
│   │       ├── media/
│   │       │   └── page.tsx
│   │       ├── settings/
│   │       │   └── page.tsx
│   │       └── login/
│   │           └── page.tsx
│   └── api/
│       └── admin/
│           ├── properties/route.ts
│           ├── neighborhoods/route.ts
│           ├── blog/route.ts
│           ├── leads/route.ts
│           ├── users/route.ts
│           ├── seo/route.ts
│           ├── media/route.ts
│           ├── settings/route.ts
│           └── auth/route.ts
├── components/
│   └── admin/
│       ├── layout/
│       │   ├── AdminLayout.tsx       # Main layout wrapper
│       │   ├── AdminSidebar.tsx      # Navigation sidebar
│       │   └── AdminHeader.tsx       # Top header
│       ├── dashboard/
│       │   └── DashboardContent.tsx
│       ├── properties/
│       │   └── PropertyComponents.tsx
│       ├── leads/
│       │   └── LeadComponents.tsx
│       ├── users/
│       │   └── UserComponents.tsx
│       ├── seo/
│       │   └── SeoComponents.tsx
│       ├── media/
│       │   └── MediaComponents.tsx
│       └── common/
│           └── index.tsx             # Shared UI components
├── lib/
│   ├── admin/
│   │   ├── api.ts                    # API client
│   │   └── utils.ts                  # Utility functions
│   ├── auth.ts                       # NextAuth configuration
│   └── prisma.ts                     # Prisma client
├── types/
│   └── admin.ts                      # TypeScript definitions
└── prisma/
    └── schema.prisma                 # Database schema
```

---

## Database Setup

### Step 1: Update Database Connection

Add your database URL to `.env`:

```env
DATABASE_URL="postgresql://user:password@localhost:5432/maisondorient?schema=public"
```

### Step 2: Generate Prisma Client

```bash
npx prisma generate
```

### Step 3: Run Migrations

```bash
npx prisma migrate dev --name init
```

### Step 4: Seed Initial Data

Create a seed file `prisma/seed.ts`:

```typescript
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // Create admin user
  const hashedPassword = await bcrypt.hash('admin123', 12);
  
  await prisma.user.upsert({
    where: { email: 'admin@maisondorient.com' },
    update: {},
    create: {
      email: 'admin@maisondorient.com',
      name: 'Admin',
      password: hashedPassword,
      role: 'SUPER_ADMIN',
      isActive: true,
    },
  });

  // Create neighborhoods
  const neighborhoods = [
    { name: { en: 'Bebek', tr: 'Bebek' }, slug: { en: 'bebek', tr: 'bebek' } },
    { name: { en: 'Galata', tr: 'Galata' }, slug: { en: 'galata', tr: 'galata' } },
    { name: { en: 'Nişantaşı', tr: 'Nişantaşı' }, slug: { en: 'nisantasi', tr: 'nisantasi' } },
    { name: { en: 'Sarıyer', tr: 'Sarıyer' }, slug: { en: 'sariyer', tr: 'sariyer' } },
  ];

  for (const neighborhood of neighborhoods) {
    await prisma.neighborhood.upsert({
      where: { slug: neighborhood.slug },
      update: {},
      create: neighborhood,
    });
  }

  console.log('Seed completed successfully');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
```

Run the seed:

```bash
npx prisma db seed
```

---

## Environment Configuration

Add these environment variables to your `.env.local`:

```env
# Database
DATABASE_URL="postgresql://..."

# NextAuth
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secret-key-here"

# Cloudinary
CLOUDINARY_CLOUD_NAME="your-cloud-name"
CLOUDINARY_API_KEY="your-api-key"
CLOUDINARY_API_SECRET="your-api-secret"

# Optional: Google Analytics
NEXT_PUBLIC_GA_ID="G-XXXXXXXXXX"
```

---

## Authentication Setup

### Step 1: Create Auth API Route

Create `src/app/api/auth/[...nextauth]/route.ts`:

```typescript
import NextAuth from 'next-auth';
import { authOptions } from '@/lib/auth';

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
```

### Step 2: Add Session Provider

Update your root layout or create an admin-specific provider:

```typescript
// src/app/[locale]/admin/layout.tsx
import { SessionProvider } from 'next-auth/react';

export default function AdminLayout({ children }) {
  return (
    <SessionProvider>
      {children}
    </SessionProvider>
  );
}
```

### Step 3: Protect Admin Routes

Create middleware for admin protection `src/middleware.ts`:

```typescript
import { withAuth } from 'next-auth/middleware';

export default withAuth({
  pages: {
    signIn: '/admin/login',
  },
});

export const config = {
  matcher: ['/:locale/admin/:path*'],
};
```

---

## SEO Configuration

### Global SEO Settings

The admin panel provides comprehensive SEO management:

1. **Page-Level SEO**: Configure meta tags for each page type (home, properties, neighborhoods, services, contact, blog)

2. **Property-Level SEO**: Each property has its own SEO settings including:
   - Meta title and description (bilingual)
   - Open Graph tags
   - Schema.org structured data
   - Canonical URLs

3. **Redirects Management**: Create and manage 301/302 redirects with hit tracking

4. **Sitemap Configuration**: Customize sitemap generation for each content type

### Implementing SEO on Frontend

Use the SEO data in your pages:

```typescript
// src/app/[locale]/properties/[id]/page.tsx
import { Metadata } from 'next';
import { prisma } from '@/lib/prisma';

export async function generateMetadata({ params }): Promise<Metadata> {
  const property = await prisma.property.findUnique({
    where: { id: params.id },
    include: { seo: true },
  });

  const locale = params.locale;
  const seo = property?.seo;

  return {
    title: seo?.metaTitle?.[locale] || property?.title?.[locale],
    description: seo?.metaDescription?.[locale] || property?.description?.[locale]?.substring(0, 160),
    openGraph: {
      title: seo?.ogTitle?.[locale] || property?.title?.[locale],
      description: seo?.ogDescription?.[locale],
      images: seo?.ogImage ? [seo.ogImage] : property?.images?.[0]?.url ? [property.images[0].url] : [],
    },
    robots: {
      index: !seo?.noIndex,
      follow: !seo?.noFollow,
    },
    alternates: {
      canonical: seo?.canonicalUrl,
    },
  };
}
```

---

## Cloudinary Integration

### Step 1: Install Cloudinary SDK

```bash
npm install cloudinary
```

### Step 2: Create Upload API

```typescript
// src/app/api/admin/media/upload/route.ts
import { v2 as cloudinary } from 'cloudinary';
import { NextRequest, NextResponse } from 'next/server';

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const folder = formData.get('folder') as string || 'maisondorient';

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    const result = await new Promise((resolve, reject) => {
      cloudinary.uploader.upload_stream(
        {
          folder,
          resource_type: 'auto',
        },
        (error, result) => {
          if (error) reject(error);
          else resolve(result);
        }
      ).end(buffer);
    });

    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json({ error: 'Upload failed' }, { status: 500 });
  }
}
```

---

## Customization Guide

### Adding New Admin Sections

1. Create components in `src/components/admin/[section]/`
2. Add page route in `src/app/[locale]/admin/[section]/`
3. Create API route in `src/app/api/admin/[section]/`
4. Add navigation item in `AdminSidebar.tsx`
5. Add type definitions in `src/types/admin.ts`

### Modifying the Color Scheme

Update the color variables in `src/app/globals.css`:

```css
@theme {
  --color-primary: #2C3E50;
  --color-accent-gold: #D4AF37;
  /* ... */
}
```

### Adding New Languages

1. Add locale to `src/i18n/routing.ts`
2. Create message file `messages/[locale].json`
3. Update bilingual fields in database schema

---

## Troubleshooting

### Common Issues

**1. Prisma Client Not Generated**
```bash
npx prisma generate
```

**2. Database Connection Issues**
- Verify DATABASE_URL format
- Ensure database server is running
- Check firewall settings

**3. Authentication Not Working**
- Verify NEXTAUTH_SECRET is set
- Check NEXTAUTH_URL matches your domain
- Clear browser cookies

**4. Images Not Loading**
- Verify Cloudinary credentials
- Check image domains in next.config.ts

### Getting Help

For issues not covered here, check:
- Next.js documentation: https://nextjs.org/docs
- Prisma documentation: https://www.prisma.io/docs
- NextAuth documentation: https://next-auth.js.org

---

## Security Checklist

- [ ] Change default admin password
- [ ] Set strong NEXTAUTH_SECRET
- [ ] Enable HTTPS in production
- [ ] Review user roles and permissions
- [ ] Configure rate limiting for API routes
- [ ] Set up database backups
- [ ] Enable audit logging

---

## Quick Start Commands

```bash
# Install dependencies
npm install

# Generate Prisma client
npx prisma generate

# Run migrations
npx prisma migrate dev

# Seed database
npx prisma db seed

# Start development server
npm run dev

# Access admin panel
# http://localhost:3000/admin
# Default login: admin@maisondorient.com / admin123
```

---

© 2026 Maison d'Orient Admin Panel - Integration Guide v1.0
