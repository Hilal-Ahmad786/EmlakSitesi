# Maison d'Orient Admin Panel

A comprehensive, production-ready admin panel for real estate website management, built with Next.js 15, TypeScript, and Prisma.

## Features

### 🏠 Property Management
- Full CRUD operations with bilingual support (EN/TR)
- Image gallery with drag-and-drop upload
- Property status workflow (Draft → Published → Sold/Rented)
- Featured properties management
- Advanced filtering and search

### 📊 Dashboard
- Real-time statistics overview
- Recent leads and activities
- Top-performing properties
- Quick action cards

### 🔍 SEO Management
- Global SEO settings
- Per-page meta configuration
- Open Graph and Twitter Cards
- Schema.org structured data
- 301/302 redirect management
- Sitemap configuration
- Robots.txt management

### 👥 Lead Management
- Lead tracking with status workflow
- Priority levels and assignment
- Notes and activity timeline
- Export functionality
- Quick actions (call, email, schedule)

### 👤 User Management
- Role-based access control (5 levels)
- User activation/deactivation
- Password reset
- Activity logging

### 🖼️ Media Library
- Cloudinary integration
- Folder organization
- Grid/List view
- Bulk operations
- Image picker for forms

### ⚙️ Settings
- Company information
- Contact details
- Social media links
- Analytics integration (GA4, GTM, FB Pixel)
- Email configuration

## Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Database**: PostgreSQL/MySQL via Prisma ORM
- **Authentication**: NextAuth.js
- **Styling**: Tailwind CSS
- **Media**: Cloudinary
- **Icons**: Lucide React

## Quick Start

```bash
# 1. Copy admin panel files to your project
# 2. Install dependencies
npm install @prisma/client next-auth @auth/prisma-adapter bcryptjs react-dropzone

# 3. Generate Prisma client
npx prisma generate

# 4. Run migrations
npx prisma migrate dev

# 5. Seed database
npx prisma db seed

# 6. Start development
npm run dev
```

## Default Credentials

```
Email: admin@maisondorient.com
Password: admin123
```

⚠️ **Important**: Change these credentials immediately in production!

## Documentation

See [INTEGRATION_GUIDE.md](./INTEGRATION_GUIDE.md) for detailed integration instructions.

## File Structure

```
admin-panel/
├── prisma/
│   └── schema.prisma          # Database schema
├── src/
│   ├── app/
│   │   ├── [locale]/admin/    # Admin pages
│   │   └── api/admin/         # API routes
│   ├── components/admin/      # UI components
│   ├── lib/
│   │   ├── admin/             # API client & utils
│   │   ├── auth.ts            # Auth configuration
│   │   └── prisma.ts          # Database client
│   └── types/
│       └── admin.ts           # Type definitions
├── INTEGRATION_GUIDE.md       # Detailed docs
└── README.md                  # This file
```

## Environment Variables

```env
DATABASE_URL="postgresql://..."
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secret-key"
CLOUDINARY_CLOUD_NAME="..."
CLOUDINARY_API_KEY="..."
CLOUDINARY_API_SECRET="..."
```

## Support

For issues and questions, refer to the integration guide or contact the development team.

---

Built with ❤️ for Maison d'Orient
