'use client';

import { useState, useEffect } from 'react';
import { AdminLayout } from '@/components/admin/layout/AdminLayout';
import { 
  GlobalSeoSettings, 
  RedirectsManager, 
  SitemapSettings 
} from '@/components/admin/seo/SeoComponents';
import { Tabs } from '@/components/admin/common';
import { adminApi } from '@/lib/admin/api';
import type { GlobalSeoSettings as GlobalSeoSettingsType, Redirect, SitemapConfig } from '@/types/admin';

interface SeoPageProps {
  params: { locale: string };
}

export default function SeoPage({ params }: SeoPageProps) {
  const { locale } = params;
  const [activeTab, setActiveTab] = useState('global');
  const [globalSettings, setGlobalSettings] = useState<GlobalSeoSettingsType | null>(null);
  const [redirects, setRedirects] = useState<Redirect[]>([]);
  const [sitemapConfig, setSitemapConfig] = useState<SitemapConfig | null>(null);
  const [loading, setLoading] = useState(true);

  const tabs = [
    { id: 'global', label: 'Global SEO' },
    { id: 'redirects', label: 'Redirects' },
    { id: 'sitemap', label: 'Sitemap' },
  ];

  useEffect(() => {
    fetchSeoData();
  }, []);

  const fetchSeoData = async () => {
    setLoading(true);
    try {
      const [seoResponse, redirectsResponse, sitemapResponse] = await Promise.all([
        adminApi.seo.getGlobal(),
        adminApi.seo.getRedirects(),
        adminApi.seo.getSitemap(),
      ]);
      setGlobalSettings(seoResponse);
      setRedirects(redirectsResponse.data);
      setSitemapConfig(sitemapResponse);
    } catch (error) {
      console.error('Failed to fetch SEO data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveGlobal = async (data: GlobalSeoSettingsType) => {
    try {
      await adminApi.seo.updateGlobal(data);
      setGlobalSettings(data);
    } catch (error) {
      console.error('Failed to save global SEO:', error);
      throw error;
    }
  };

  const handleAddRedirect = async (data: Omit<Redirect, 'id' | 'hits' | 'createdAt'>) => {
    try {
      await adminApi.seo.createRedirect(data);
      fetchSeoData();
    } catch (error) {
      console.error('Failed to add redirect:', error);
      throw error;
    }
  };

  const handleUpdateRedirect = async (id: string, data: Partial<Redirect>) => {
    try {
      await adminApi.seo.updateRedirect(id, data);
      fetchSeoData();
    } catch (error) {
      console.error('Failed to update redirect:', error);
      throw error;
    }
  };

  const handleDeleteRedirect = async (id: string) => {
    try {
      await adminApi.seo.deleteRedirect(id);
      fetchSeoData();
    } catch (error) {
      console.error('Failed to delete redirect:', error);
      throw error;
    }
  };

  const handleSaveSitemap = async (data: SitemapConfig) => {
    try {
      await adminApi.seo.updateSitemap(data);
      setSitemapConfig(data);
    } catch (error) {
      console.error('Failed to save sitemap config:', error);
      throw error;
    }
  };

  const handleRegenerateSitemap = async () => {
    try {
      await adminApi.seo.regenerateSitemap();
      alert('Sitemap regenerated successfully!');
    } catch (error) {
      console.error('Failed to regenerate sitemap:', error);
      throw error;
    }
  };

  return (
    <AdminLayout locale={locale}>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">SEO Management</h1>
          <p className="text-sm text-gray-500 mt-1">
            Configure search engine optimization settings for your website
          </p>
        </div>

        <Tabs tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />

        {activeTab === 'global' && globalSettings && (
          <GlobalSeoSettings
            settings={globalSettings}
            onSave={handleSaveGlobal}
          />
        )}

        {activeTab === 'redirects' && (
          <RedirectsManager
            redirects={redirects}
            onAdd={handleAddRedirect}
            onUpdate={handleUpdateRedirect}
            onDelete={handleDeleteRedirect}
          />
        )}

        {activeTab === 'sitemap' && sitemapConfig && (
          <SitemapSettings
            config={sitemapConfig}
            onSave={handleSaveSitemap}
            onRegenerate={handleRegenerateSitemap}
          />
        )}
      </div>
    </AdminLayout>
  );
}
